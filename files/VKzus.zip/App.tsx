import React, { useState, useEffect } from 'react';
import { User, Role } from './types';
import { db, initDb, generateApiKey } from './services/api';
import { AdminDashboard } from './pages/AdminDashboard';
import { Store } from './pages/Store';
import { Button, Input, Card } from './components/ui';
import { motion } from 'framer-motion';
import { Lock, User as UserIcon, X } from 'lucide-react';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showLogin, setShowLogin] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [isRegister, setIsRegister] = useState(false);

  useEffect(() => {
    const checkSession = async () => {
      await initDb();
      const stored = localStorage.getItem('odzre_user');
      if (stored) setUser(JSON.parse(stored));
      setIsLoading(false);
    };
    checkSession();
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!loginData.username.trim() || !loginData.password.trim()) {
      alert("Please enter both username and password.");
      return;
    }

    setIsLoading(true);
    
    const users = (await db.get<User[]>('odzre:users')) || [];
    
    if (isRegister) {
      if (users.find(u => u.username === loginData.username)) {
        alert('Username taken');
        setIsLoading(false);
        return;
      }
      const newUser: User = {
        id: `u_${Date.now()}`,
        username: loginData.username,
        password: loginData.password,
        role: Role.MEMBER,
        balance: 0,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${loginData.username}`,
        apiKey: generateApiKey(),
        createdAt: new Date().toISOString()
      };
      await db.set('odzre:users', [...users, newUser]);
      setUser(newUser);
      localStorage.setItem('odzre_user', JSON.stringify(newUser));
    } else {
      const found = users.find(u => u.username === loginData.username && u.password === loginData.password);
      if (found) {
        setUser(found);
        localStorage.setItem('odzre_user', JSON.stringify(found));
      } else {
        alert('Invalid credentials');
      }
    }
    setShowLogin(false);
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('odzre_user');
    setLoginData({ username: '', password: '' });
    window.location.reload();
  };

  if (isLoading) return null;

  // If user is Admin, show Admin Dashboard
  if (user?.role === Role.ADMIN) {
    return <AdminDashboard />;
  }

  // Default: Show Store (Public Access)
  return (
    <>
      <Store user={user} onLogout={() => setShowLogin(true)} />
      
      {/* Login Modal Overlay */}
      {showLogin && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
           <motion.div initial={{scale:0.9, opacity: 0}} animate={{scale:1, opacity: 1}} className="w-full max-w-sm relative">
              <button onClick={() => setShowLogin(false)} className="absolute -top-12 right-0 text-white p-2 bg-white/10 rounded-full"><X /></button>
              <Card className="bg-slate-900 border border-slate-700 shadow-2xl">
                <div className="text-center mb-6">
                   <h2 className="text-2xl font-bold text-white">Welcome Back</h2>
                   <p className="text-slate-400 text-sm">Login to manage your orders</p>
                </div>
                <form onSubmit={handleAuth} className="space-y-4">
                   <div className="relative">
                      <UserIcon className="absolute left-3 top-3.5 text-slate-500" size={18} />
                      <input 
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="Username"
                        value={loginData.username}
                        onChange={e => setLoginData({...loginData, username: e.target.value})}
                      />
                   </div>
                   <div className="relative">
                      <Lock className="absolute left-3 top-3.5 text-slate-500" size={18} />
                      <input 
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="Password"
                        type="password"
                        value={loginData.password}
                        onChange={e => setLoginData({...loginData, password: e.target.value})}
                      />
                   </div>
                   <Button type="submit" className="w-full py-3 shadow-xl shadow-indigo-500/20" isLoading={isLoading}>
                      {isRegister ? 'Register' : 'Login'}
                   </Button>
                </form>
                <div className="mt-4 text-center space-y-2">
                   <button onClick={() => setIsRegister(!isRegister)} className="text-sm text-slate-400 hover:text-white">
                      {isRegister ? 'Have account? Login' : 'No account? Register'}
                   </button>
                   {!isRegister && (
                      <button onClick={() => { setLoginData({username:'admin', password:'123'}); }} className="block w-full text-xs text-indigo-500/50 hover:text-indigo-500 mt-2">
                        (Demo: Admin Login)
                      </button>
                   )}
                </div>
              </Card>
           </motion.div>
        </div>
      )}
    </>
  );
};

export default App;