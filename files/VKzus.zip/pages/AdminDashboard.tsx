import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, Package, Users, Settings, Database, 
  Plus, Trash2, Upload, Menu, X,
  Wallet, ShoppingCart, Check, Edit3, Search, Eye, ChevronDown
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area
} from 'recharts';
import { db, uploadFile } from '../services/api';
import { User, Product, Order, AppConfig, StockItem } from '../types';
import { Button, Card, Input, Badge, formatIDR, Modal } from '../components/ui';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'stock' | 'users' | 'settings'>('overview');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  
  const [users, setUsers] = useState<User[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [stockItems, setStockItems] = useState<StockItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [config, setConfig] = useState<AppConfig>({ storeName: '', bannerUrl: '' });
  const [isLoading, setIsLoading] = useState(false);

  // Product Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({ 
    name: '', price: 0, category: 'General', description: '', inputFields: [], isPopular: false 
  });
  const [productImage, setProductImage] = useState<File | null>(null);
  const [tempInputField, setTempInputField] = useState('');
  const [adminProductFilter, setAdminProductFilter] = useState('ALL');
  
  // Stock State
  const [stockInput, setStockInput] = useState({ productId: '', data: '' });
  const [stockSearch, setStockSearch] = useState('');
  const [showAllStock, setShowAllStock] = useState(false);

  // User/Balance State
  const [manualBalance, setManualBalance] = useState<{userId: string, amount: string}>({ userId: '', amount: '' });

  // Transaction/Order State
  const [transactionSearch, setTransactionSearch] = useState('');
  const [showAllTransactions, setShowAllTransactions] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Order | null>(null);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    const [u, p, o, c, s] = await Promise.all([
      db.get<User[]>('odzre:users'),
      db.get<Product[]>('odzre:products'),
      db.get<Order[]>('odzre:orders'),
      db.get<AppConfig>('odzre:config'),
      db.get<StockItem[]>('odzre:stock')
    ]);
    setUsers(u || []);
    setProducts(p || []);
    setOrders(o || []);
    setConfig(c || { storeName: 'Odzre Shop', bannerUrl: '' });
    setStockItems(s || []);
  };

  // --- Chart Logic (Real Data) ---
  const chartData = useMemo(() => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const currentYear = new Date().getFullYear();
    
    return months.map((m, index) => {
      const monthOrders = orders.filter(o => {
        const d = new Date(o.date);
        return d.getMonth() === index && d.getFullYear() === currentYear && o.status === 'SUCCESS';
      });
      
      const revenue = monthOrders.reduce((acc, o) => acc + o.totalPrice, 0);
      // Assuming 20% profit margin for demo purposes since we don't have cost price
      const profit = revenue * 0.2; 

      return { name: m, revenue, profit };
    });
  }, [orders]);

  const weeklyData = useMemo(() => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const today = new Date();
    const last7Days = [];
    
    for(let i=6; i>=0; i--) {
        const d = new Date(today);
        d.setDate(today.getDate() - i);
        last7Days.push(d);
    }

    return last7Days.map(day => {
        const dayName = days[day.getDay()];
        const dayOrders = orders.filter(o => {
            const od = new Date(o.date);
            return od.getDate() === day.getDate() && 
                   od.getMonth() === day.getMonth() && 
                   od.getFullYear() === day.getFullYear();
        });
        return {
            name: dayName,
            orders: dayOrders.length,
            revenue: dayOrders.reduce((acc, o) => acc + o.totalPrice, 0)
        };
    });
  }, [orders]);

  // --- Product Logic ---
  const getProductStockCount = (pid: string) => stockItems.filter(s => s.productId === pid && !s.isSold).length;
  const uniqueCategories = ['ALL', ...Array.from(new Set(products.map(p => p.category)))];

  const handleSaveProduct = async () => {
    if (!productForm.name || !productForm.price) return;
    setIsLoading(true);
    
    let imgUrl = productForm.image || "https://placehold.co/400x400/1e293b/FFF?text=Product";
    if (productImage) {
      const uploaded = await uploadFile(productImage);
      if (uploaded) imgUrl = uploaded;
    }

    if (editingId) {
      // Update existing
      const updatedProducts = products.map(p => {
        if (p.id === editingId) {
          return {
            ...p,
            ...productForm,
            price: Number(productForm.price),
            image: imgUrl,
            // ensure inputFields is preserved if not changed, or updated if changed
            inputFields: productForm.inputFields || [],
            isPopular: productForm.isPopular || false
          } as Product;
        }
        return p;
      });
      await db.set('odzre:products', updatedProducts);
      setProducts(updatedProducts);
      setEditingId(null);
    } else {
      // Create new
      const newProd: Product = {
        id: `p_${Date.now()}`,
        name: productForm.name!,
        description: productForm.description || '',
        price: Number(productForm.price),
        category: productForm.category || 'General',
        image: imgUrl,
        sold: 0,
        inputFields: productForm.inputFields || [],
        isPopular: productForm.isPopular || false
      };
      const updated = [...products, newProd];
      await db.set('odzre:products', updated);
      setProducts(updated);
    }

    // Reset Form
    setProductForm({ name: '', price: 0, category: 'General', description: '', inputFields: [], isPopular: false });
    setProductImage(null);
    setIsLoading(false);
  };

  const handleEditClick = (p: Product) => {
    setEditingId(p.id);
    setProductForm({ ...p });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setProductForm({ name: '', price: 0, category: 'General', description: '', inputFields: [], isPopular: false });
    setProductImage(null);
  };

  // --- Stock & User Logic ---
  const handleAddStock = async () => {
    if (!stockInput.productId || !stockInput.data) return;
    setIsLoading(true);
    const newItem: StockItem = {
      id: `stk_${Date.now()}`,
      productId: stockInput.productId,
      data: stockInput.data,
      isSold: false,
      addedAt: new Date().toISOString()
    };
    const updated = [...stockItems, newItem];
    await db.set('odzre:stock', updated);
    setStockItems(updated);
    setStockInput(prev => ({ ...prev, data: '' }));
    setIsLoading(false);
  };

  const handleUpdateBalance = async (userId: string) => {
    if (!manualBalance.amount || manualBalance.userId !== userId) return;
    const amount = parseInt(manualBalance.amount.replace(/\./g, ''));
    if (isNaN(amount)) return;

    const updatedUsers = users.map(u => {
      if (u.id === userId) return { ...u, balance: u.balance + amount };
      return u;
    });
    await db.set('odzre:users', updatedUsers);
    setUsers(updatedUsers);
    setManualBalance({ userId: '', amount: '' });
  };

  const handleConfigSave = async () => {
    setIsLoading(true);
    await db.set('odzre:config', config);
    setIsLoading(false);
  };

  // Aggregates & Filtering
  const totalRevenue = orders.reduce((a,b) => a + b.totalPrice, 0);
  
  // Filter Transactions
  const filteredOrders = orders.filter(o => 
    o.id.toLowerCase().includes(transactionSearch.toLowerCase())
  ).reverse();
  
  const displayedOrders = showAllTransactions ? filteredOrders : filteredOrders.slice(0, 5);

  // Filter Stock
  const filteredStock = stockItems.filter(s => 
    s.id.toLowerCase().includes(stockSearch.toLowerCase())
  ).reverse();

  const displayedStock = showAllStock ? filteredStock : filteredStock.slice(0, 10);

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden">
      {/* Sidebar */}
      <AnimatePresence>
        {(isSidebarOpen || window.innerWidth >= 1024) && (
          <motion.aside 
            initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
            className="fixed lg:static z-50 w-72 h-screen bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl lg:shadow-none"
          >
            <div className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img src="https://cdn.odzre.my.id/3cw.png" className="w-10 h-10 rounded-xl" />
                <div>
                  <h1 className="font-black text-xl text-white tracking-tight">Odzre Admin</h1>
                  <p className="text-xs text-indigo-400 font-medium">Management System</p>
                </div>
              </div>
              <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 text-slate-400"><X /></button>
            </div>

            <nav className="flex-1 px-4 space-y-2 mt-4 overflow-y-auto">
              {[
                { id: 'overview', icon: LayoutDashboard, label: 'Dashboard' },
                { id: 'products', icon: Package, label: 'Products' },
                { id: 'stock', icon: Database, label: 'Stock Data' },
                { id: 'users', icon: Users, label: 'Users & Saldo' },
                { id: 'settings', icon: Settings, label: 'Web Settings' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id as any); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all font-medium text-sm ${
                    activeTab === item.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <item.icon size={18} />
                  {item.label}
                </button>
              ))}
            </nav>

            <div className="p-6 mt-auto border-t border-slate-800">
               <Button variant="outline" className="w-full" onClick={() => window.location.reload()}>Logout</Button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 h-screen overflow-y-auto scroll-smooth bg-slate-950 relative">
        <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-white bg-slate-800 rounded-lg"><Menu /></button>
            <div>
              <h2 className="text-xl font-bold text-white capitalize">{activeTab === 'overview' ? 'Dashboard Overview' : activeTab}</h2>
              <p className="text-xs text-slate-500 hidden md:block">Real-time business analytics and insights</p>
            </div>
          </div>
          <div className="flex gap-4">
             <a href="/" className="hidden sm:flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 rounded-lg text-sm font-bold hover:bg-indigo-500/20 transition-colors">
                <ShoppingCart size={16}/> Open Shop
             </a>
             <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-white font-bold">A</div>
          </div>
        </header>

        <div className="p-4 lg:p-8 pb-24 max-w-[1600px] mx-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' && (
              <motion.div key="ov" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                
                {/* Stats Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                  {[
                    { title: 'Total Revenue', value: formatIDR(totalRevenue), icon: Wallet, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
                    { title: 'Active Users', value: users.length, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
                    { title: 'Total Orders', value: orders.length, icon: Package, color: 'text-purple-400', bg: 'bg-purple-500/10' },
                  ].map((stat, i) => (
                    <div key={i} className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                      <div className="flex justify-between items-start mb-4">
                        <div className={`p-3 rounded-xl ${stat.bg}`}>
                          <stat.icon className={stat.color} size={24} />
                        </div>
                      </div>
                      <h3 className="text-slate-400 text-sm font-medium mb-1">{stat.title}</h3>
                      <p className="text-2xl font-black text-white">{stat.value}</p>
                    </div>
                  ))}
                </div>

                {/* Charts Section */}
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  {/* Revenue vs Profit */}
                  <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="text-lg font-bold text-white">Financial Performance (Real-Time)</h3>
                      <div className="flex gap-2">
                         <span className="text-xs text-slate-500 bg-slate-800 px-2 py-1 rounded">Jan - Dec</span>
                      </div>
                    </div>
                    <div className="h-80 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                          <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorProf" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                          <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} dy={10} />
                          <YAxis 
                            stroke="#64748b" 
                            axisLine={false} 
                            tickLine={false} 
                            domain={[0, 1000000]} 
                            tickFormatter={(val) => `Rp${val/1000}k`} 
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px' }}
                            itemStyle={{ color: '#fff' }}
                            formatter={(value: number) => formatIDR(value)}
                          />
                          <Area type="monotone" dataKey="revenue" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                          <Area type="monotone" dataKey="profit" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorProf)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Traffic Sources */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                    <h3 className="text-lg font-bold text-white mb-6">Orders This Week</h3>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                         <BarChart data={weeklyData}>
                           <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                           <XAxis dataKey="name" stroke="#64748b" axisLine={false} tickLine={false} fontSize={10} />
                           <Tooltip 
                             cursor={{fill: '#1e293b'}}
                             contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px' }}
                           />
                           <Bar dataKey="orders" fill="#6366f1" radius={[4, 4, 0, 0]} name="Orders" />
                         </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Recent Transactions */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                   <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
                      <h3 className="text-lg font-bold text-white">Recent Transactions</h3>
                      <div className="relative w-full sm:w-auto">
                        <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
                        <input 
                          className="w-full sm:w-64 bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                          placeholder="Search Transaction ID..."
                          value={transactionSearch}
                          onChange={e => { setTransactionSearch(e.target.value); setShowAllTransactions(true); }}
                        />
                      </div>
                   </div>
                   <div className="overflow-x-auto">
                      <table className="w-full text-left">
                         <thead>
                            <tr className="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-800">
                               <th className="pb-4 pl-4">Customer</th>
                               <th className="pb-4">Status</th>
                               <th className="pb-4">Amount</th>
                               <th className="pb-4 text-right">Action</th>
                            </tr>
                         </thead>
                         <tbody className="divide-y divide-slate-800">
                            {displayedOrders.map((order) => {
                               const user = users.find(u => u.id === order.userId);
                               return (
                                 <tr key={order.id} className="hover:bg-slate-800/50 transition-colors">
                                    <td className="py-4 pl-4">
                                       <div className="flex items-center gap-3">
                                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">
                                             {user?.username.substring(0,2).toUpperCase() || 'GU'}
                                          </div>
                                          <div>
                                             <p className="font-bold text-white text-sm">{user?.username || 'Unknown User'}</p>
                                             <p className="text-xs text-slate-500">{order.id.slice(-8)}</p>
                                          </div>
                                       </div>
                                    </td>
                                    <td className="py-4">
                                       <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                          Completed
                                       </span>
                                    </td>
                                    <td className="py-4">
                                       <p className="text-white font-bold text-sm">{formatIDR(order.totalPrice)}</p>
                                    </td>
                                    <td className="py-4 text-right pr-4">
                                       <button 
                                         onClick={() => setSelectedTransaction(order)}
                                         className="text-indigo-400 hover:text-indigo-300 text-xs font-bold"
                                       >
                                         View Details
                                       </button>
                                    </td>
                                 </tr>
                               );
                            })}
                         </tbody>
                      </table>
                      {filteredOrders.length === 0 && (
                        <div className="text-center py-8 text-slate-500">No transactions found.</div>
                      )}
                      {filteredOrders.length > 5 && !showAllTransactions && (
                        <div className="mt-4 text-center">
                          <button onClick={() => setShowAllTransactions(true)} className="text-sm text-indigo-400 hover:text-white font-medium flex items-center justify-center gap-1 w-full">
                            View All Transactions <ChevronDown size={14}/>
                          </button>
                        </div>
                      )}
                   </div>
                </div>

                {/* Transaction Detail Modal */}
                <Modal 
                  isOpen={!!selectedTransaction} 
                  onClose={() => setSelectedTransaction(null)} 
                  title="Transaction Details"
                >
                  {selectedTransaction && (
                    <div className="space-y-4">
                       <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                          <div className="flex justify-between mb-2">
                             <span className="text-slate-500 text-sm">Order ID</span>
                             <span className="text-white font-mono text-sm">{selectedTransaction.id}</span>
                          </div>
                          <div className="flex justify-between mb-2">
                             <span className="text-slate-500 text-sm">Date</span>
                             <span className="text-white text-sm">{new Date(selectedTransaction.date).toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                             <span className="text-slate-500 text-sm">Total Amount</span>
                             <span className="text-emerald-400 font-bold">{formatIDR(selectedTransaction.totalPrice)}</span>
                          </div>
                       </div>
                       <div className="space-y-2">
                          <h4 className="text-sm font-bold text-white">Items Purchased</h4>
                          {selectedTransaction.items.map((item, idx) => (
                            <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                               <div className="flex justify-between">
                                  <span className="text-white font-medium">{item.productName}</span>
                                  <span className="text-slate-400 text-sm">x{item.quantity}</span>
                               </div>
                               {item.stockData?.map((sd, i) => (
                                 <div key={i} className="mt-2 p-2 bg-slate-900 rounded text-xs font-mono text-slate-300 break-all">
                                   {sd}
                                 </div>
                               ))}
                            </div>
                          ))}
                       </div>
                    </div>
                  )}
                </Modal>

              </motion.div>
            )}

            {activeTab === 'products' && (
              <motion.div key="prod" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                <Card title={editingId ? "Edit Product" : "Add New Product"} action={editingId && <Button size="xs" variant="secondary" onClick={handleCancelEdit}>Cancel Edit</Button>}>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <Input placeholder="Product Name" value={productForm.name} onChange={e => setProductForm({...productForm, name: e.target.value})} />
                      <Input 
                        placeholder="Price (Rp)" 
                        value={productForm.price ? productForm.price.toLocaleString('id-ID') : ''} 
                        onChange={e => {
                           const val = parseInt(e.target.value.replace(/\./g, '')) || 0;
                           setProductForm({...productForm, price: val});
                        }} 
                      />
                      <Input placeholder="Category" value={productForm.category} onChange={e => setProductForm({...productForm, category: e.target.value})} />
                      <textarea 
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none h-24 text-sm"
                        placeholder="Description"
                        value={productForm.description}
                        onChange={e => setProductForm({...productForm, description: e.target.value})}
                      />
                    </div>
                    <div className="space-y-4">
                      {/* Required Inputs Section - Aligned */}
                      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                         <div className="flex items-center justify-between mb-2">
                           <h4 className="text-sm text-slate-400 font-bold">Required User Inputs</h4>
                         </div>
                         <div className="flex items-stretch gap-2 mb-2">
                            <div className="flex-1">
                               <Input placeholder="e.g. User ID" value={tempInputField} onChange={e => setTempInputField(e.target.value)} className="mb-0" />
                            </div>
                            <Button size="sm" className="px-0 w-[46px] flex-shrink-0" onClick={() => {
                              if(tempInputField) {
                                setProductForm({...productForm, inputFields: [...(productForm.inputFields || []), tempInputField]});
                                setTempInputField('');
                              }
                            }}><Plus size={20}/></Button>
                         </div>
                         <div className="flex flex-wrap gap-2">
                            {productForm.inputFields?.map((field, i) => (
                              <Badge key={i} className="flex items-center gap-1 pr-1 cursor-pointer" color="bg-slate-700">
                                {field} <X size={12} onClick={() => setProductForm({...productForm, inputFields: productForm.inputFields?.filter((_, idx) => idx !== i)})} />
                              </Badge>
                            ))}
                         </div>
                      </div>
                      
                      <div className="flex items-center gap-4 p-4 bg-slate-950 rounded-xl border border-slate-800">
                         <label className="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" checked={productForm.isPopular} onChange={e => setProductForm({...productForm, isPopular: e.target.checked})} className="w-5 h-5 rounded bg-slate-800 border-slate-600 text-indigo-600 focus:ring-0" />
                            <span className="text-white font-medium text-sm">Set as Popular</span>
                         </label>
                         <div className="flex-1 h-10 flex items-center justify-end gap-2">
                            <input type="file" id="prodImg" hidden onChange={e => setProductImage(e.target.files?.[0] || null)} />
                            <label htmlFor="prodImg" className="flex items-center gap-2 text-sm text-indigo-400 cursor-pointer hover:text-indigo-300">
                               <Upload size={16} /> {productImage ? 'Selected' : 'Upload Img'}
                            </label>
                         </div>
                      </div>
                      
                      <Button onClick={handleSaveProduct} isLoading={isLoading} className="w-full" icon={editingId ? Edit3 : Plus}>
                        {editingId ? "Update Product" : "Create Product"}
                      </Button>
                    </div>
                  </div>
                </Card>

                <div className="space-y-4">
                  {/* Category Filter */}
                  <div className="flex items-center gap-3 overflow-x-auto pb-2">
                     <span className="text-slate-500 text-sm font-bold">Filter:</span>
                     {uniqueCategories.map(cat => (
                        <button 
                          key={cat} 
                          onClick={() => setAdminProductFilter(cat)}
                          className={`px-3 py-1 rounded-full text-xs font-bold border ${
                            adminProductFilter === cat 
                            ? 'bg-indigo-500 border-indigo-500 text-white' 
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-600'
                          }`}
                        >
                           {cat}
                        </button>
                     ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                     {products.filter(p => adminProductFilter === 'ALL' || p.category === adminProductFilter).map(p => (
                       <Card key={p.id} className={`group relative overflow-hidden transition-all cursor-pointer border hover:border-indigo-500/50 ${editingId === p.id ? 'ring-2 ring-indigo-500 border-indigo-500 bg-indigo-900/10' : ''}`}>
                          <div onClick={() => handleEditClick(p)} className="flex gap-4">
                             <img src={p.image} className="w-20 h-20 rounded-lg object-cover bg-slate-800" />
                             <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-white truncate">{p.name}</h4>
                                <p className="text-indigo-400 font-bold">{formatIDR(p.price)}</p>
                                <div className="flex gap-2 mt-2">
                                   <Badge color="bg-slate-700">Stock: {getProductStockCount(p.id)}</Badge>
                                   {p.isPopular && <Badge color="bg-amber-500">Popular</Badge>}
                                </div>
                             </div>
                          </div>
                          <button 
                            onClick={(e) => {
                               e.stopPropagation();
                               if(window.confirm('Delete product?')) {
                                  const updated = products.filter(x => x.id !== p.id);
                                  db.set('odzre:products', updated);
                                  setProducts(updated);
                                  if(editingId === p.id) handleCancelEdit();
                               }
                            }} 
                            className="absolute top-2 right-2 p-2 bg-red-500/10 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-all opacity-0 group-hover:opacity-100 z-10"
                          >
                            <Trash2 size={16} />
                          </button>
                       </Card>
                     ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'stock' && (
              <motion.div key="stk" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <Card title="Add Stock Data (1 Item)">
                   <p className="text-sm text-slate-500 mb-4">Select a product and enter the secret data (Voucher code, Account details, etc).</p>
                   <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
                      <select 
                        className="w-full bg-slate-950 border border-slate-800 text-white rounded-xl px-4 h-[46px] outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
                        value={stockInput.productId}
                        onChange={e => setStockInput({...stockInput, productId: e.target.value})}
                      >
                        <option value="">Select Product...</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                      <Input 
                        placeholder="Enter Data (e.g. XGH-123-CODE)" 
                        value={stockInput.data}
                        onChange={e => setStockInput({...stockInput, data: e.target.value})}
                        className="lg:mb-0"
                      />
                      <Button onClick={handleAddStock} isLoading={isLoading} icon={Plus}>Add Stock</Button>
                   </div>
                </Card>

                <Card title="Stock Inventory">
                   <div className="flex justify-between items-center mb-4">
                      <div className="relative w-full max-w-xs">
                        <Search className="absolute left-3 top-2.5 text-slate-500" size={16} />
                        <input 
                          className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                          placeholder="Search Stock ID..."
                          value={stockSearch}
                          onChange={e => { setStockSearch(e.target.value); setShowAllStock(true); }}
                        />
                      </div>
                   </div>
                   <div className="overflow-x-auto">
                     <table className="w-full text-left text-sm">
                       <thead>
                         <tr className="text-slate-500 border-b border-slate-800">
                           <th className="p-3">Stock ID</th>
                           <th className="p-3">Product</th>
                           <th className="p-3">Data Content</th>
                           <th className="p-3">Status</th>
                           <th className="p-3">Action</th>
                         </tr>
                       </thead>
                       <tbody>
                         {displayedStock.map(s => {
                           const prod = products.find(p => p.id === s.productId);
                           return (
                             <tr key={s.id} className="border-b border-slate-800/50 hover:bg-slate-800/20">
                               <td className="p-3 font-mono text-slate-500 text-xs">{s.id}</td>
                               <td className="p-3 font-medium text-white">{prod?.name || 'Unknown'}</td>
                               <td className="p-3 font-mono text-slate-400 truncate max-w-[200px]">{s.data}</td>
                               <td className="p-3">
                                 <Badge color={s.isSold ? 'bg-red-500' : 'bg-emerald-500'}>{s.isSold ? 'SOLD' : 'READY'}</Badge>
                               </td>
                               <td className="p-3">
                                  {!s.isSold && (
                                    <button onClick={async () => {
                                      const updated = stockItems.filter(x => x.id !== s.id);
                                      await db.set('odzre:stock', updated);
                                      setStockItems(updated);
                                    }} className="text-red-400 hover:text-red-300"><Trash2 size={16} /></button>
                                  )}
                               </td>
                             </tr>
                           );
                         })}
                       </tbody>
                     </table>
                     {filteredStock.length > 10 && !showAllStock && (
                        <div className="mt-4 text-center">
                          <button onClick={() => setShowAllStock(true)} className="text-sm text-indigo-400 hover:text-white font-medium flex items-center justify-center gap-1 w-full">
                            View All Stock <ChevronDown size={14}/>
                          </button>
                        </div>
                      )}
                   </div>
                </Card>
              </motion.div>
            )}

            {activeTab === 'users' && (
              <motion.div key="users" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Card title="User Management">
                  <div className="overflow-x-auto pb-4">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="text-slate-500 border-b border-slate-800 text-xs uppercase tracking-wider">
                          <th className="p-4 font-bold">User Details</th>
                          <th className="p-4 font-bold text-center">Current Balance</th>
                          <th className="p-4 font-bold">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users.map(u => (
                          <tr key={u.id} className="border-b border-slate-800/50 hover:bg-slate-900/50 transition-colors group">
                            <td className="p-4 align-middle">
                              <div className="flex items-center gap-3">
                                <img src={u.avatar} className="w-8 h-8 rounded-full" alt="" />
                                <div>
                                  <p className="text-white font-bold text-sm">{u.username}</p>
                                  <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">{u.role}</span>
                                </div>
                              </div>
                            </td>
                            <td className="p-4 font-mono text-emerald-400 font-bold align-middle text-center">{formatIDR(u.balance)}</td>
                            <td className="p-4 align-middle">
                              <div className="flex gap-2 items-center h-10">
                                <Input 
                                  className="mb-0 h-full min-w-[120px]"
                                  placeholder="Rp Amount"
                                  value={manualBalance.userId === u.id ? manualBalance.amount : ''}
                                  onChange={e => {
                                    const val = e.target.value.replace(/\D/g, '');
                                    const formatted = val ? parseInt(val).toLocaleString('id-ID') : '';
                                    setManualBalance({ userId: u.id, amount: formatted });
                                  }}
                                />
                                <Button 
                                  size="sm" 
                                  className="aspect-square px-0 h-full w-10 flex items-center justify-center" 
                                  onClick={() => handleUpdateBalance(u.id)} 
                                  disabled={manualBalance.userId !== u.id || !manualBalance.amount}
                                >
                                   <Plus size={18} />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div key="set" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-xl">
                 <Card title="Website Configuration">
                    <Input label="Store Name" value={config.storeName} onChange={e => setConfig({...config, storeName: e.target.value})} />
                    <div className="mb-6">
                       <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Banner Image URL</label>
                       <div className="relative aspect-[3/1] rounded-xl overflow-hidden border border-slate-800 mb-2 group">
                          <img src={config.bannerUrl} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                             <p className="text-white text-xs">Preview</p>
                          </div>
                       </div>
                       <Input value={config.bannerUrl} onChange={e => setConfig({...config, bannerUrl: e.target.value})} />
                    </div>
                    <Button onClick={handleConfigSave} isLoading={isLoading} className="w-full">Save Changes</Button>
                 </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};