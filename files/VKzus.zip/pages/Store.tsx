import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, LogOut, User as UserIcon, Search, ArrowRight, Package, Bell, CheckCircle, X, ArrowLeft } from 'lucide-react';
import { db } from '../services/api';
import { User, Product, Order, AppConfig, StockItem, Role } from '../types';
import { Button, Card, Badge, formatIDR, Input } from '../components/ui';

interface StoreProps {
  user: User | null;
  onLogout: () => void;
}

// Meteor Component
const Meteors = ({ number = 20 }: { number?: number }) => {
  const meteors = new Array(number).fill(true);
  return (
    <div className="meteor-container">
      {meteors.map((el, idx) => (
        <span
          key={"meteor" + idx}
          className="meteor"
          style={{
            top: Math.floor(Math.random() * 100) + "%",
            left: Math.floor(Math.random() * 100) + "%",
            animationDelay: Math.random() * 1 + 0.2 + "s",
            animationDuration: Math.floor(Math.random() * 8 + 2) + "s",
          }}
        ></span>
      ))}
    </div>
  );
};

export const Store: React.FC<StoreProps> = ({ user, onLogout }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [stockItems, setStockItems] = useState<StockItem[]>([]);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  
  const [view, setView] = useState<'shop' | 'profile' | 'detail'>('shop');
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [userInputValues, setUserInputValues] = useState<Record<string, string>>({});
  const [isDescExpanded, setIsDescExpanded] = useState(false);
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(user);

  // Initial Load
  useEffect(() => {
    const init = async () => {
      const [p, c, s] = await Promise.all([
        db.get<Product[]>('odzre:products'),
        db.get<AppConfig>('odzre:config'),
        db.get<StockItem[]>('odzre:stock')
      ]);
      setProducts(p || []);
      setConfig(c);
      setStockItems(s || []);
      if (user) refreshUserData();
    };
    init();
    const interval = setInterval(() => {
       db.get<StockItem[]>('odzre:stock').then(s => setStockItems(s || []));
       if(user) refreshUserData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const refreshUserData = async () => {
    if (!user) return;
    const users = await db.get<User[]>('odzre:users');
    const me = users?.find(u => u.id === user.id);
    if (me) setCurrentUser(me);
    
    const allOrders = await db.get<Order[]>('odzre:orders');
    if (allOrders) setOrders(allOrders.filter(o => o.userId === user.id).reverse());
  };

  const getAvailableStock = (pid: string) => stockItems.filter(s => s.productId === pid && !s.isSold);

  const getCategories = () => {
    const cats = Array.from(new Set(products.map(p => p.category)));
    return ['ALL', ...cats.sort()];
  };

  const handleProductClick = (p: Product) => {
    setSelectedProduct(p);
    setUserInputValues({});
    setIsDescExpanded(false);
    setView('detail');
    window.scrollTo(0,0);
  };

  const handleBuy = async () => {
    if (!currentUser) {
       alert("Please Login to continue");
       window.location.reload(); 
       return;
    }
    if (!selectedProduct) return;

    // Validate Inputs
    const missingInput = selectedProduct.inputFields?.find(f => !userInputValues[f]);
    if (missingInput) {
      alert(`Please fill in ${missingInput}`);
      return;
    }

    setIsProcessing(true);
    
    if (currentUser.balance < selectedProduct.price) {
      alert("Insufficient Balance. Please top up via Admin.");
      setIsProcessing(false);
      return;
    }

    const availableStock = getAvailableStock(selectedProduct.id);
    if (availableStock.length === 0) {
      alert("Out of Stock!");
      setIsProcessing(false);
      return;
    }
    const itemToSell = availableStock[0];

    try {
      // Deduct Balance
      const allUsers = (await db.get<User[]>('odzre:users')) || [];
      const updatedUsers = allUsers.map(u => {
        if (u.id === currentUser.id) return { ...u, balance: u.balance - selectedProduct.price };
        return u;
      });
      await db.set('odzre:users', updatedUsers);

      // Update Stock
      const allStock = (await db.get<StockItem[]>('odzre:stock')) || [];
      const updatedStock = allStock.map(s => {
        if (s.id === itemToSell.id) return { ...s, isSold: true };
        return s;
      });
      await db.set('odzre:stock', updatedStock);

      // Create Order
      const newOrder: Order = {
        id: `ord_${Date.now()}`,
        userId: currentUser.id,
        items: [{
          productId: selectedProduct.id,
          productName: selectedProduct.name,
          price: selectedProduct.price,
          quantity: 1,
          // STORE ID AND DATA TOGETHER
          stockData: [`[ID: ${itemToSell.id}] | ${itemToSell.data}`],
          userInputData: userInputValues
        }],
        totalPrice: selectedProduct.price,
        status: 'SUCCESS',
        date: new Date().toISOString(),
        viewed: false
      };
      const allOrders = (await db.get<Order[]>('odzre:orders')) || [];
      await db.set('odzre:orders', [...allOrders, newOrder]);

      setSelectedProduct(null);
      setUserInputValues({});
      await refreshUserData();
      
      alert("Purchase Successful! Check your Profile to see your item data.");
      setView('profile');
      
    } catch (e) {
      alert("Transaction Failed");
    }
    setIsProcessing(false);
  };

  const hasUnreadOrders = orders.some(o => !o.viewed);
  
  const markOrdersRead = async () => {
    if(!hasUnreadOrders) return;
    const allOrders = await db.get<Order[]>('odzre:orders') || [];
    const updated = allOrders.map(o => {
      if(o.userId === currentUser?.id) return {...o, viewed: true};
      return o;
    });
    await db.set('odzre:orders', updated);
    setOrders(orders.map(o => ({...o, viewed: true})));
  };

  const filteredProducts = products.filter(p => activeCategory === 'ALL' || p.category === activeCategory);

  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 font-sans overflow-x-hidden">
      
      {/* Navbar Transparent Blur */}
      <nav className="fixed top-0 w-full z-50 bg-[#020617]/60 backdrop-blur-md border-b border-white/5 transition-all">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <div onClick={() => { setView('shop'); setSelectedProduct(null); }} className="flex items-center gap-3 cursor-pointer group">
            <img src="https://cdn.odzre.my.id/3cw.png" className="w-10 h-10 transition-transform group-hover:scale-110" />
            <span className="font-black text-xl tracking-tight text-white">{config?.storeName || 'Odzre'}</span>
          </div>

          <div className="flex items-center gap-4">
            {currentUser ? (
              <>
                <div className="hidden md:flex flex-col items-end mr-2">
                   <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Balance</span>
                   <span className="font-black text-emerald-400 text-lg">{formatIDR(currentUser.balance)}</span>
                </div>
                <button 
                  onClick={() => { setView('profile'); markOrdersRead(); }} 
                  className="relative p-1 rounded-full border-2 border-transparent hover:border-indigo-500 transition-all"
                >
                  <img src={currentUser.avatar} className="w-9 h-9 rounded-full" />
                  {hasUnreadOrders && <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-[#020617]" />}
                </button>
              </>
            ) : (
               <Button onClick={onLogout} size="sm" className="shadow-lg shadow-indigo-500/20">Login</Button>
            )}
          </div>
        </div>
      </nav>

      <main className="pt-24 pb-20">
        {view === 'shop' && (
          <motion.div initial={{opacity: 0}} animate={{opacity: 1}} className="max-w-7xl mx-auto px-4 sm:px-6">
            {/* Hero Banner with Meteors - Added container padding to show meteors around it */}
            <div className="relative py-4 px-2 md:px-8 mb-8"> 
               {/* Meteor container is outside the card so it shows in the padding area */}
               <Meteors number={25} />
               <div className="relative rounded-3xl overflow-hidden aspect-[16/9] md:aspect-[21/8] group shadow-2xl shadow-indigo-900/20 z-10">
                <img 
                  src={config?.bannerUrl || 'https://picsum.photos/1200/600'} 
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 relative z-10" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent flex items-end p-6 md:p-12 z-20">
                   <div className="max-w-2xl">
                      <Badge className="mb-4 bg-indigo-600/80 backdrop-blur">Official Store</Badge>
                      <h1 className="text-3xl md:text-6xl font-black text-white mb-2 leading-tight">
                        Digital Goods <br/> <span className="text-indigo-500">Instant Delivery.</span>
                      </h1>
                   </div>
                </div>
               </div>
            </div>

            {/* Popular Section */}
            {products.some(p => p.isPopular) && (
              <div className="mb-12">
                 <div className="flex items-center gap-3 mb-6">
                    <img src="https://cdn.odzre.my.id/q51.gif" className="h-8 w-8" />
                    <h2 className="text-2xl font-bold text-white">Popular Now</h2>
                 </div>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {products.filter(p => p.isPopular).map(p => (
                       <Card key={p.id} className="bg-gradient-to-b from-indigo-900/20 to-slate-900/50 border-indigo-500/30 hover:border-indigo-500 cursor-pointer group p-4" >
                          <div onClick={() => handleProductClick(p)} className="relative aspect-square rounded-xl overflow-hidden mb-3">
                             <img src={p.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                          </div>
                          <h3 className="font-bold text-white truncate">{p.name}</h3>
                          <p className="text-indigo-400 font-black">{formatIDR(p.price)}</p>
                       </Card>
                    ))}
                 </div>
              </div>
            )}

            {/* Category Navigation */}
            <div className="mb-8 overflow-x-auto pb-2 scrollbar-hide">
               <div className="flex gap-2 min-w-max">
                  {getCategories().map(cat => (
                     <button 
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`px-6 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap ${
                           activeCategory === cat 
                           ? 'bg-white text-black' 
                           : 'bg-slate-900 text-slate-400 border border-slate-800 hover:border-slate-600'
                        }`}
                     >
                        {cat}
                     </button>
                  ))}
               </div>
            </div>

            {/* Filtered Products */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
              {filteredProducts.map(p => {
                const stockCount = getAvailableStock(p.id).length;
                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                    key={p.id} 
                    onClick={() => handleProductClick(p)}
                    className="bg-slate-900/40 border border-slate-800/50 rounded-2xl p-3 hover:bg-slate-800/50 transition-all cursor-pointer group hover:-translate-y-1"
                  >
                     <div className="relative aspect-square rounded-xl overflow-hidden mb-3 bg-slate-800">
                        <img src={p.image} className="w-full h-full object-cover" />
                        {stockCount === 0 && (
                          <div className="absolute inset-0 bg-black/70 backdrop-blur-[2px] flex items-center justify-center">
                             <span className="font-black text-white text-sm uppercase tracking-widest border-2 border-white px-2 py-1">Sold Out</span>
                          </div>
                        )}
                     </div>
                     <div className="px-1">
                        <h3 className="font-bold text-slate-200 text-sm md:text-base line-clamp-1 group-hover:text-indigo-400 transition-colors">{p.name}</h3>
                        <div className="flex items-center justify-between mt-2">
                           <span className="text-sm font-black text-white">{formatIDR(p.price)}</span>
                           <span className="text-[10px] text-slate-500">{stockCount} left</span>
                        </div>
                     </div>
                  </motion.div>
                );
              })}
              {filteredProducts.length === 0 && (
                 <div className="col-span-full text-center py-20 text-slate-500">No products in this category.</div>
              )}
            </div>
          </motion.div>
        )}

        {/* Product Detail View (Replaces Shop View) */}
        {view === 'detail' && selectedProduct && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="max-w-5xl mx-auto px-4">
            <Button variant="ghost" onClick={() => setView('shop')} className="mb-6 pl-0 gap-2 text-slate-400 hover:text-white">
               <ArrowLeft size={18}/> Back to Shop
            </Button>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
               <div className="space-y-4">
                  <div className="aspect-square rounded-3xl overflow-hidden bg-slate-800 border border-slate-700 shadow-2xl shadow-indigo-900/10">
                     <img src={selectedProduct.image} className="w-full h-full object-cover" />
                  </div>
               </div>

               <div className="space-y-8">
                  <div>
                     <div className="flex gap-2 mb-4">
                        <Badge color="bg-indigo-500/20 text-indigo-300">{selectedProduct.category}</Badge>
                        {selectedProduct.isPopular && <Badge color="bg-amber-500 text-white">Popular</Badge>}
                     </div>
                     <h1 className="text-3xl md:text-5xl font-black text-white mb-4 leading-tight">{selectedProduct.name}</h1>
                     <p className="text-3xl font-black text-indigo-400">{formatIDR(selectedProduct.price)}</p>
                  </div>

                  <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
                     <h3 className="text-sm font-bold text-slate-400 uppercase mb-2">Description</h3>
                     <p className="text-slate-300 leading-relaxed whitespace-pre-wrap break-words">
                        {isDescExpanded 
                           ? (selectedProduct.description || "") 
                           : (selectedProduct.description?.slice(0, 150) || "") + (selectedProduct.description && selectedProduct.description.length > 150 ? "..." : "")
                        }
                     </p>
                     {selectedProduct.description && selectedProduct.description.length > 150 && (
                        <button 
                           onClick={() => setIsDescExpanded(!isDescExpanded)}
                           className="text-indigo-400 text-sm font-bold mt-3 hover:text-indigo-300 flex items-center gap-1"
                        >
                           {isDescExpanded ? "Show Less" : "Read More"}
                        </button>
                     )}
                  </div>

                  {selectedProduct.inputFields && selectedProduct.inputFields.length > 0 && (
                     <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
                        <h4 className="text-lg font-bold text-white flex items-center gap-2">
                           <UserIcon size={20} className="text-indigo-500"/> 
                           Required Information
                        </h4>
                        <p className="text-sm text-slate-500">Please fill in the details below correctly to receive your item.</p>
                        {selectedProduct.inputFields.map(field => (
                           <Input 
                              key={field} 
                              label={field} 
                              placeholder={`Enter ${field}`}
                              value={userInputValues[field] || ''}
                              onChange={e => setUserInputValues({...userInputValues, [field]: e.target.value})}
                              className="mb-0"
                           />
                        ))}
                     </div>
                  )}

                  <div className="flex items-center gap-4 pt-4 border-t border-slate-800">
                     <div className="flex-1">
                        <p className="text-xs text-slate-500 uppercase font-bold mb-1">Availability</p>
                        <p className="text-white font-bold flex items-center gap-2">
                           <span className={`w-2 h-2 rounded-full ${getAvailableStock(selectedProduct.id).length > 0 ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                           {getAvailableStock(selectedProduct.id).length} Units Left
                        </p>
                     </div>
                     <Button 
                        className="px-12 py-4 text-lg shadow-xl shadow-indigo-600/20" 
                        onClick={handleBuy} 
                        isLoading={isProcessing}
                        disabled={getAvailableStock(selectedProduct.id).length === 0}
                     >
                        {getAvailableStock(selectedProduct.id).length > 0 ? 'Buy Now' : 'Sold Out'}
                     </Button>
                  </div>
               </div>
            </div>
          </motion.div>
        )}

        {view === 'profile' && currentUser && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-4xl mx-auto px-4 mt-8">
             <Button variant="ghost" onClick={() => setView('shop')} className="mb-6 pl-0 gap-2 text-slate-400 hover:text-white"><ArrowLeft size={18}/> Back to Shop</Button>
             
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Profile Card */}
                <div className="space-y-6">
                   <Card className="text-center relative overflow-hidden border-indigo-500/30">
                      <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-indigo-600/20 to-transparent pointer-events-none" />
                      <img src={currentUser.avatar} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-slate-900 relative z-10" />
                      <h2 className="text-2xl font-bold text-white">{currentUser.username}</h2>
                      <Badge color="bg-indigo-500">{currentUser.role}</Badge>
                      
                      <div className="mt-6 p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                         <p className="text-xs text-slate-400 uppercase font-bold mb-1">Current Balance</p>
                         <p className="text-2xl font-black text-emerald-400">{formatIDR(currentUser.balance)}</p>
                      </div>

                      {currentUser.role === Role.ADMIN && (
                         <Button onClick={() => window.location.reload()} className="w-full mt-4" variant="secondary">Open Admin Dashboard</Button>
                      )}
                      <Button onClick={onLogout} variant="danger" className="w-full mt-2" size="sm">Logout</Button>
                   </Card>
                </div>

                {/* Orders List */}
                <div className="md:col-span-2 space-y-4">
                   <h3 className="text-xl font-bold text-white flex items-center gap-2"><Package /> Purchase History</h3>
                   {orders.length === 0 ? (
                      <div className="text-center py-12 bg-slate-900/30 rounded-3xl border border-slate-800 border-dashed">
                         <p className="text-slate-500">No purchases yet.</p>
                         <Button variant="ghost" onClick={() => setView('shop')} className="mt-2 text-indigo-400">Start Shopping</Button>
                      </div>
                   ) : (
                      orders.map((order) => (
                         <motion.div 
                            initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
                            key={order.id}
                            className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden"
                         >
                            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950/30">
                               <div>
                                  <span className="text-xs font-bold text-slate-500 uppercase">Order ID: {order.id.slice(-8)}</span>
                                  <p className="text-xs text-slate-400">{new Date(order.date).toLocaleString()}</p>
                               </div>
                               <Badge color="bg-emerald-500/20 text-emerald-400" className="border border-emerald-500/30">Successful</Badge>
                            </div>
                            <div className="p-4">
                               {order.items.map((item, idx) => (
                                  <div key={idx} className="space-y-4">
                                     <div className="flex justify-between items-start">
                                        <h4 className="font-bold text-white text-lg">{item.productName}</h4>
                                        <span className="font-bold text-indigo-400">{formatIDR(item.price)}</span>
                                     </div>
                                     
                                     {/* Secret Data Reveal */}
                                     {item.stockData && (
                                        <div className="bg-indigo-950/30 border border-indigo-500/30 rounded-xl p-4">
                                           <p className="text-xs font-bold text-indigo-300 uppercase mb-2 flex items-center gap-2"><CheckCircle size={12}/> Purchased Item Data</p>
                                           {item.stockData.map((data, i) => (
                                              <div key={i} className="font-mono text-sm text-white bg-black/30 p-3 rounded-lg break-all select-all cursor-pointer hover:bg-black/50">
                                                 {data}
                                              </div>
                                           ))}
                                           <p className="text-[10px] text-slate-500 mt-2 italic">Click text to copy. Keep this data safe.</p>
                                        </div>
                                     )}

                                     {/* User Input Data Display */}
                                     {item.userInputData && Object.keys(item.userInputData).length > 0 && (
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                           {Object.entries(item.userInputData).map(([key, val]) => (
                                              <div key={key} className="bg-slate-950 p-2 rounded border border-slate-800">
                                                 <span className="text-slate-500 block">{key}</span>
                                                 <span className="text-white font-medium">{val}</span>
                                              </div>
                                           ))}
                                        </div>
                                     )}
                                  </div>
                               ))}
                            </div>
                         </motion.div>
                      ))
                   )}
                </div>
             </div>
          </motion.div>
        )}
      </main>
    </div>
  );
};