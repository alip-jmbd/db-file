import { User, Product, Order, AppConfig, Role, CdnResponse, StockItem } from '../types';

const REDIS_URL = "https://trusty-wolf-39066.upstash.io";
const REDIS_TOKEN = "AZiaAAIncDI4NmVkMDgxNWI1ODY0ZmEwOGJmZWU4ZDFlZjNhNDY3M3AyMzkwNjY";
const UPLOAD_URL = "https://cdn.odzre.my.id/upload";

const redisCall = async (command: string, ...args: (string | number)[]) => {
  try {
    const response = await fetch(`${REDIS_URL}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${REDIS_TOKEN}` },
      body: JSON.stringify([command, ...args]),
    });
    const data = await response.json();
    return data.result;
  } catch (e) {
    console.error(e);
    return null;
  }
};

export const db = {
  async get<T>(key: string): Promise<T | null> {
    const result = await redisCall('GET', key);
    return result ? JSON.parse(result) : null;
  },
  async set(key: string, value: any) {
    return await redisCall('SET', key, JSON.stringify(value));
  },
};

export const initDb = async () => {
  let users = await db.get<User[]>('odzre:users');
  if (!users) {
    users = [];
    await db.set('odzre:users', users);
  }

  const adminExists = users.find(u => u.username === 'admin');
  if (!adminExists) {
    const adminUser: User = {
      id: 'u_admin',
      username: 'admin',
      password: '123', 
      role: Role.ADMIN,
      balance: 999999999,
      apiKey: 'odzre_sk_admin_master',
      createdAt: new Date().toISOString(),
      avatar: 'https://ui-avatars.com/api/?name=Admin&background=6366f1&color=fff'
    };
    users.push(adminUser);
    await db.set('odzre:users', users);
  }

  const products = await db.get('odzre:products');
  if (!products) await db.set('odzre:products', []);

  const categories = await db.get('odzre:categories');
  if (!categories) await db.set('odzre:categories', []);

  const orders = await db.get('odzre:orders');
  if (!orders) await db.set('odzre:orders', []);

  const stock = await db.get('odzre:stock');
  if (!stock) await db.set('odzre:stock', []);

  const config = await db.get('odzre:config');
  if (!config) await db.set('odzre:config', { storeName: 'Odzre Shop', bannerUrl: 'https://picsum.photos/1200/600' });
};

export const uploadFile = async (file: File): Promise<string | null> => {
  const formData = new FormData();
  formData.append('file', file);
  try {
    const res = await fetch(UPLOAD_URL, { method: 'POST', body: formData });
    const data: CdnResponse = await res.json();
    return data.url;
  } catch {
    return null;
  }
};

export const generateApiKey = () => 'odzre_' + Math.random().toString(36).substr(2, 16);