export enum Role {
  MEMBER = 'MEMBER',
  ADMIN = 'ADMIN'
}

export interface User {
  id: string;
  username: string;
  password?: string;
  role: Role;
  balance: number;
  avatar?: string;
  apiKey: string;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  sold: number;
  inputFields: string[]; 
  isPopular: boolean;
}

export interface StockItem {
  id: string;
  productId: string;
  data: string; 
  isSold: boolean;
  addedAt: string;
}

export interface Order {
  id: string;
  userId: string;
  items: {
    productId: string;
    productName: string;
    price: number;
    quantity: number;
    stockData?: string[]; 
    userInputData?: Record<string, string>; 
  }[];
  totalPrice: number;
  status: 'SUCCESS' | 'FAILED';
  date: string;
  viewed: boolean;
}

export interface AppConfig {
  storeName: string;
  bannerUrl: string;
}

export interface CdnResponse {
  creator: string;
  time: string;
  url: string;
}