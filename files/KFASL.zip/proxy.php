<?php
// proxy.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: text/plain");

if (isset($_GET['url'])) {
    $url = $_GET['url'];
    
    // Ini header biar gak ketauan kalau yang akses itu bot
    $options = [
        "http" => [
            "method" => "GET",
            "header" => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n" .
                        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"
        ]
    ];
    
    $context = stream_context_create($options);
    $content = @file_get_contents($url, false, $context);
    
    if ($content !== false) {
        echo $content;
    } else {
        http_response_code(404);
        echo "Gagal mengambil konten dari URL.";
    }
}
?>
