<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
  
  protected $guarded = [];
    public function kendaraan() { return $this->belongsTo(Kendaraan::class); }
public function tarif() { return $this->belongsTo(Tarif::class); }
public function area_parkir() { return $this->belongsTo(AreaParkir::class); }
public function user() { return $this->belongsTo(User::class); }
}
