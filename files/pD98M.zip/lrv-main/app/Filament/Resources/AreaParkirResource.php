<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AreaParkirResource\Pages;
use App\Models\AreaParkir;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class AreaParkirResource extends Resource
{
    protected static ?string $model = AreaParkir::class;
    protected static ?string $navigationIcon = 'heroicon-o-map';
    protected static ?string $navigationLabel = 'Area Parkir';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make()->schema([
                Forms\Components\TextInput::make('nama_area')
                    ->required(),
                Forms\Components\TextInput::make('kapasitas')
                    ->numeric()
                    ->required(),
                Forms\Components\TextInput::make('terisi')
                    ->numeric()
                    ->default(0),
            ])
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('nama_area')->searchable(),
            Tables\Columns\TextColumn::make('kapasitas'),
            Tables\Columns\TextColumn::make('terisi')
                ->description(fn ($record) => ($record->kapasitas - $record->terisi) . ' Slot Tersisa'),
        ])->actions([
            Tables\Actions\EditAction::make(),
            Tables\Actions\DeleteAction::make(),
        ]);
    }

    public static function canViewAny(): bool { return auth()->user()->role === 'admin'; }

    public static function getPages(): array {
        return [
            'index' => Pages\ListAreaParkirs::route('/'),
            'create' => Pages\CreateAreaParkir::route('/create'),
            'edit' => Pages\EditAreaParkir::route('/{record}/edit'),
        ];
    }
}