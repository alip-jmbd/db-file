<?php

namespace App\Filament\Resources;

use App\Filament\Resources\KendaraanResource\Pages;
use App\Models\Kendaraan;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class KendaraanResource extends Resource
{
    protected static ?string $model = Kendaraan::class;
    protected static ?string $navigationIcon = 'heroicon-o-truck';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make()->schema([
                Forms\Components\TextInput::make('plat_nomor')->required(),
                Forms\Components\TextInput::make('jenis_kendaraan')->required(),
                Forms\Components\TextInput::make('warna'),
                Forms\Components\TextInput::make('pemilik')->required(),
                Forms\Components\Hidden::make('user_id')->default(auth()->id()),
            ])
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('plat_nomor')->searchable(),
            Tables\Columns\TextColumn::make('jenis_kendaraan'),
            Tables\Columns\TextColumn::make('pemilik'),
        ])->actions([
            Tables\Actions\EditAction::make(),
            Tables\Actions\DeleteAction::make(),
        ]);
    }

    public static function canViewAny(): bool { return auth()->user()->role === 'admin'; }

    public static function getPages(): array {
        return [
            'index' => Pages\ListKendaraans::route('/'),
            'create' => Pages\CreateKendaraan::route('/create'),
            'edit' => Pages\EditKendaraan::route('/{record}/edit'),
        ];
    }
}