<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TransaksiResource\Pages;
use App\Models\Transaksi;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class TransaksiResource extends Resource
{
    protected static ?string $model = Transaksi::class;
    protected static ?string $navigationIcon = 'heroicon-o-ticket';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make()->schema([
                Forms\Components\Select::make('kendaraan_id')
                    ->relationship('kendaraan', 'plat_nomor')
                    ->searchable()->required(),
                Forms\Components\Select::make('tarif_id')
                    ->relationship('tarif', 'jenis_kendaraan')
                    ->label('Tipe')->required(),
                Forms\Components\Select::make('area_parkir_id')
                    ->relationship('area_parkir', 'nama_area')
                    ->required(),
                Forms\Components\DateTimePicker::make('waktu_masuk')->default(now()),
                Forms\Components\Select::make('status')
                    ->options(['masuk' => 'Masuk', 'keluar' => 'Keluar'])
                    ->default('masuk'),
                Forms\Components\Hidden::make('user_id')->default(auth()->id()),
            ])->columns(2)
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('kendaraan.plat_nomor')->searchable(),
            Tables\Columns\TextColumn::make('tarif.jenis_kendaraan')->label('Jenis'),
            Tables\Columns\TextColumn::make('waktu_masuk')->dateTime(),
            Tables\Columns\TextColumn::make('status')->badge()->color(fn($state)=>$state==='masuk'?'success':'danger'),
            Tables\Columns\TextColumn::make('biaya_total')->money('IDR'),
        ])->actions([
            Tables\Actions\EditAction::make(),
        ]);
    }

    public static function canViewAny(): bool { 
        return in_array(auth()->user()->role, ['admin', 'petugas', 'owner']); 
    }

    public static function getPages(): array {
        return [
            'index' => Pages\ListTransaksis::route('/'),
            'create' => Pages\CreateTransaksi::route('/create'),
            'edit' => Pages\EditTransaksi::route('/{record}/edit'),
        ];
    }
}