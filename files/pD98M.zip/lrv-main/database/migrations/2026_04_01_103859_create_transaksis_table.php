<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transaksis', function (Blueprint $table) {
    $table->id(); // Ini id_parkir
    // Relasi-relasi (Foreign Keys)
    $table->foreignId('kendaraan_id')->constrained('kendaraans');
    $table->foreignId('tarif_id')->constrained('tarifs');
    $table->foreignId('user_id')->constrained('users');
    $table->foreignId('area_parkir_id')->constrained('area_parkirs');
    
    $table->dateTime('waktu_masuk');
    $table->dateTime('waktu_keluar')->nullable(); // Boleh kosong pas baru masuk
    $table->integer('durasi_jam')->nullable();
    $table->decimal('biaya_total', 10, 0)->nullable();
    $table->enum('status', ['masuk', 'keluar']);
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transaksis');
    }
};
