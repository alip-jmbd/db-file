<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tarifs', function (Blueprint $table) {
    $table->id(); // Ini id_tarif
    $table->enum('jenis_kendaraan', ['motor', 'mobil', 'lainnya']);
    $table->decimal('tarif_per_jam', 10, 0); // (10, 0) artinya 10 digit, tanpa koma
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tarifs');
    }
};
