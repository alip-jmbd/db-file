<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('kendaraans', function (Blueprint $table) {
    $table->id(); // Ini id_kendaraan
    $table->string('plat_nomor', 15);
    $table->string('jenis_kendaraan', 20);
    $table->string('warna', 20);
    $table->string('pemilik', 100);
    // Relasi ke User
    $table->foreignId('user_id')->constrained('users'); 
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('kendaraans');
    }
};
